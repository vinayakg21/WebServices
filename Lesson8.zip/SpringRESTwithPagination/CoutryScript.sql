CREATE TABLE Country(
	country_id VARCHAR2(6) PRIMARY KEY,
	country_name VARCHAR2(30),
	population VARCHAR2(15)
);
INSERT INTO Country VALUES('1001','India','3234567');
INSERT INTO Country VALUES('1002','Pakistan','64567');
INSERT INTO Country VALUES('1003','SriLanka','34567');
INSERT INTO Country VALUES('1004','China','4454567');
INSERT INTO Country VALUES('1005','USA','234567');
INSERT INTO Country VALUES('1006','Canada','190567');
INSERT INTO Country VALUES('1007','Nepal','11567');
INSERT INTO Country VALUES('1008','BanglaDesh','334567');
INSERT INTO Country VALUES('1009','Bhutan','12567');
INSERT INTO Country VALUES('1010','Austrelia','34567');
INSERT INTO Country VALUES('1011','Japan','354567');
INSERT INTO Country VALUES('1012','South Koria','234567');
INSERT INTO Country VALUES('1013','England','190567');
INSERT INTO Country VALUES('1014','France','152567');
COMMIT;
