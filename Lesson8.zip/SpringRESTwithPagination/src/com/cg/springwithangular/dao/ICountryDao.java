package com.cg.springwithangular.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.cg.springwithangular.beans.Country;

public interface ICountryDao extends PagingAndSortingRepository<Country, String>{

}
