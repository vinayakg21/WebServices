package com.cg.springwithangular.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import com.cg.springwithangular.beans.Country;
import com.cg.springwithangular.dao.ICountryDao;
@Service
public class CountryServiceImpl implements ICountryService{
	@Autowired
	ICountryDao countryDao;
	@Override
	public Page<Country> getPageCountries(PageRequest req) {
		
		return countryDao.findAll(req);
	}
}
