package com.cg.springwithangular.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import com.cg.springwithangular.beans.Country;



public interface ICountryService {
	public Page<Country> getPageCountries(PageRequest req);
	/*public List<Country> getAllCountries();
	public void addCountry(Country country);
	public void deleteCountry(String id);
	public Country searchCountry(String id);*/
}
