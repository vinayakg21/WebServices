access the application with below urls:

History- first lesson 1, 2and 5from 50-70 words 

and Maths - no hw

