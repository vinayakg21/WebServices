package com.cg.springwithangular.beans;

public class Student {
	private String name;
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	public Student(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
