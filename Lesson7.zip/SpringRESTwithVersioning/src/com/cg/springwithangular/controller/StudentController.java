package com.cg.springwithangular.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.springwithangular.beans.Student;
import com.cg.springwithangular.beans.StudentV1;
import com.cg.springwithangular.service.IStudentService;

@RestController
public class StudentController {
	@Autowired
	IStudentService service;
	
		
	@RequestMapping(value = "/students",method = RequestMethod.GET,headers="Accept=application/json")
	public List<Student> getAllStudents(Model model) {
		
		
		return service.getAllStudents();
		
	}
	@RequestMapping(value = "v1/students",method = RequestMethod.GET,headers="Accept=application/json")
	public List<StudentV1> getAllStudentsV1(Model model) {
		return service.getAllStudentsV1();
		}
	}
