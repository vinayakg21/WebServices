package com.cg.springwithangular.service;

import java.util.List;
import com.cg.springwithangular.beans.Student;
import com.cg.springwithangular.beans.StudentV1;



public interface IStudentService {
	public List<Student> getAllStudents();
	public List<StudentV1> getAllStudentsV1();
}
