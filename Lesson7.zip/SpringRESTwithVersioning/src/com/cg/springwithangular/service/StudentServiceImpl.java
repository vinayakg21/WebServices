package com.cg.springwithangular.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.cg.springwithangular.beans.Student;
import com.cg.springwithangular.beans.StudentV1;
@Service
public class StudentServiceImpl implements IStudentService{
	@Override
	public List<Student> getAllStudents() {
		List<Student> slist = new ArrayList<>();
		slist.add(new Student("Abhishek"));
		slist.add(new Student("Anil"));
		slist.add(new Student("Imran"));
		return slist;
	}
	@Override
	public List<StudentV1> getAllStudentsV1() {
		List<StudentV1> slist = new ArrayList<>();
		slist.add(new StudentV1("Abhishek","Bachchan"));
		slist.add(new StudentV1("Anil","Kapoor"));
		slist.add(new StudentV1("Imran","Khan"));
		return slist;
	}

}
