Use below URL with GET request in Postman to get the output:
http://localhost:8081/SpringRESTwithVersioning/rest/students

http://localhost:8081/SpringRESTwithVersioning/rest/v1/students